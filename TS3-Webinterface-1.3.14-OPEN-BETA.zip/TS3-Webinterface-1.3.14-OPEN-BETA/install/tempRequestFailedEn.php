<html>
	<body>
		<table width="100%" bgcolor="#e0e0e0" cellpadding="0" cellspacing="0" border="0">
			<tr>
				<td>
					<table align="center" width="100%" border="0" cellpadding="0" cellspacing="0" style="max-width:650px; background-color:#fff; font-family:Verdana, Geneva, sans-serif;">
						<thead>
							<tr height="80">
								<th colspan="4" style="background-color:#FF8080; border-bottom:solid 1px #aaa; font-family:Verdana, Geneva, sans-serif; color:#900; font-size:34px;" >
									%heading%: Server Request
								</th>
							</tr>
						</thead>
						<tbody>
							<tr>
								<td colspan="4" style="padding:15px;">
									<p style="font-size:20px;">Hello %client%,</p>
									<p style="font-size:15px; font-family:Verdana, Geneva, sans-serif;"> We're Sorry, <br /> But we have rejected your server request.<br /><br />Have a great day.</p>
								</td>
							</tr>
							<tr>
								<td colspan="4" style="padding:15px;">
									<p style="font-size:15px; font-family:Verdana, Geneva, sans-serif;">Sincerely,<br/>%heading%</p>
								</td>
							</tr>
							<tr height="40">
								<td colspan="4" align="center" style="background-color:#FF8080; border-top:solid 1px #aaa; font-size:12px; ">
									(c) by L.Gmann
								</td>
							</tr>
						</tbody>
					</table>
				</td>
			</tr>
		</table>
	</body>
</html>