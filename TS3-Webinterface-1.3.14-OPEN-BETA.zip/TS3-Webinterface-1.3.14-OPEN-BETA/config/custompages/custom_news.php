<?php 
	/*
		First-Coder Teamspeak 3 Webinterface for everyone
		Copyright (C) 2017 by L.Gmann
		
		You can add here your Code you want. If you change in the config.php CUSTOM_NEWS_PAGE to true, the news will be replaced with that we have here.
		
		This page using Font awesome. You can find all Icone here: http://fontawesome.io/icons/
	*/
?>
<div class="card">
	<div class="card-block card-block-header">
		<h4 class="card-title"><i class="fa fa-smile-o"></i> MyTitle</h4>
		<h6 class="card-subtitle text-muted">MySubTitel</h6>
	</div>
	<div class="card-block">
		My own Content :)
	</div>
</div>